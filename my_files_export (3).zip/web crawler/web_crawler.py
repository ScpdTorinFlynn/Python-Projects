import requests
from bs4 import BeautifulSoup

response = requests.get("https://en.wikipedia.org/wiki/japan")
html = response.text
soup = BeautifulSoup(html, 'html.parser')
search_history = ["https://en.wikipedia.org/wiki/japan"]
def continue_crawl(target_url):
    soup = BeautifulSoup(html, 'html.parser')
    print(soup.find(id="mw-content-text").p.a)
    search_history.append("https://en.wikipedia.org" + soup.find(id="mw-content-text").p.a.get('href'))
    print(soup.find(id="mw-content-text").p.a)
    if search_history[len(search_history) - 1] == target_url:
        print("yes")
        return False
    elif len(search_history) > 25:
        print('long')
        return False
    else:
        return True
    
while continue_crawl("https://en.wikipedia.org/wiki/Analytic_philosophy"):
    continue_crawl("https://en.wikipedia.org/wiki/Analytic_philosophy")
